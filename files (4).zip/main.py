"""
HomeStation - Raspberry Pi Pico 2W
MQTT subscriber + OLED smart display

Hardware: Waveshare 1.3" OLED (SH1106, 128x64)
  DC=GP8, CS=GP9, CLK=GP10, DIN=GP11, RES=GP12
  Button A = GP15, Button B = GP17

MicroPython firmware: https://micropython.org/download/RPI_PICO_W/
Required library: sh1106.py (copy to Pico root)
  https://github.com/robert-hh/SH1106/blob/master/sh1106.py
"""

import gc
import json
import time
import network
import machine
from machine import Pin, SPI
import framebuf
from umqtt.simple import MQTTClient
import sh1106  # SH1106 OLED driver

# ─────────────────────────────────────────────
# CONFIG  — edit these
# ─────────────────────────────────────────────

WIFI_SSID     = "YOUR_WIFI_SSID"
WIFI_PASS     = "YOUR_WIFI_PASSWORD"
MQTT_BROKER   = "10.0.0.X"       # ← your Pi 4's local IP
MQTT_PORT     = 1883
MQTT_BASE     = "homestation"
CLIENT_ID     = "pico-display"

CITIES        = ["edmonton", "tokyo", "vancouver"]  # must match Pi slugs
CITY_LABELS   = ["Edmonton", "Tokyo", "Vancouver"]

# Pages: each is a (name, requires_city) tuple
PAGES         = [
    ("weather",  True),
    ("forecast", True),
    ("aqi",      True),
    ("indoor",   False),
]

# ─────────────────────────────────────────────
# DISPLAY INIT (Waveshare 1.3" SH1106)
# ─────────────────────────────────────────────

WIDTH  = 128
HEIGHT = 64

spi = SPI(1,
    baudrate=10_000_000,
    polarity=0, phase=0,
    sck=Pin(10),
    mosi=Pin(11)
)
dc  = Pin(8,  Pin.OUT)
cs  = Pin(9,  Pin.OUT)
rst = Pin(12, Pin.OUT)

oled = sh1106.SH1106_SPI(WIDTH, HEIGHT, spi, dc, rst, cs, rotate=0)
oled.fill(0)
oled.show()

# ─────────────────────────────────────────────
# STATE
# ─────────────────────────────────────────────

state = {
    "page":       0,          # current page index
    "city":       0,          # current city index
    "data":       {},         # all received MQTT data keyed by topic slug
    "last_press": 0,          # debounce timestamp
    "dirty":      True,       # needs redraw
}

# Pre-populate structure so display never crashes on missing keys
def default_weather():
    return {"temp": "--", "desc": "No data", "humidity": "--",
            "feels_like": "--", "wind_kph": "--"}

def default_forecast():
    return {"items": [{"time": "--:--", "temp": "--", "desc": "—"} for _ in range(4)]}

def default_aqi():
    return {"aqi": "--", "category": "No data", "pm2_5": "--", "pm10": "--"}

def default_indoor():
    return {"temp": "--", "humidity": "--", "pressure": "--", "source": "—"}

for city in CITIES:
    state["data"][f"weather/{city}"]  = default_weather()
    state["data"][f"forecast/{city}"] = default_forecast()
    state["data"][f"aqi/{city}"]      = default_aqi()
state["data"]["sensors/indoor"] = default_indoor()

# ─────────────────────────────────────────────
# DRAWING HELPERS
# ─────────────────────────────────────────────

def cls():
    oled.fill(0)

def text(s, x, y, col=1):
    oled.text(str(s), x, y, col)

def hline(y, col=1):
    oled.hline(0, y, WIDTH, col)

def show():
    oled.show()

def center_text(s, y, col=1):
    x = max(0, (WIDTH - len(str(s)) * 8) // 2)
    text(s, x, y, col)

def draw_bar(x, y, w, h, filled_frac, col=1):
    """Draw an outline bar + filled portion. frac in [0..1]."""
    oled.rect(x, y, w, h, col)
    fill_w = int(w * max(0, min(1, filled_frac)))
    if fill_w > 0:
        oled.fill_rect(x, y, fill_w, h, col)

def splash():
    cls()
    center_text("HomeStation", 12)
    center_text("Loading...", 28)
    center_text("v1.0", 44)
    show()

def connecting_screen(msg):
    cls()
    center_text("Connecting", 16)
    center_text(msg[:16], 30)
    show()

# ─────────────────────────────────────────────
# PAGE RENDERERS
# ─────────────────────────────────────────────

def page_weather():
    city     = CITIES[state["city"]]
    label    = CITY_LABELS[state["city"]]
    d        = state["data"].get(f"weather/{city}", default_weather())

    cls()

    # Header bar
    oled.fill_rect(0, 0, WIDTH, 12, 1)
    text(f"WEATHER  {label[:8]}", 2, 2, 0)

    # Temperature — large  (manual upscaled chars)
    temp_str = f"{d['temp']}C"
    text(temp_str, 2, 16)

    # Description
    desc = str(d["desc"])[:18]
    text(desc, 2, 28)

    # Divider
    hline(38)

    # Bottom row: humidity / wind
    text(f"Hum:{d['humidity']}%", 2, 42)
    text(f"Wind:{d['wind_kph']}k", 66, 42)

    # Feels like
    text(f"Feels {d['feels_like']}C", 2, 54)

    show()

def page_forecast():
    city  = CITIES[state["city"]]
    label = CITY_LABELS[state["city"]]
    d     = state["data"].get(f"forecast/{city}", default_forecast())
    items = d.get("items", [])

    cls()

    oled.fill_rect(0, 0, WIDTH, 12, 1)
    text(f"FORECAST {label[:7]}", 2, 2, 0)

    for i, item in enumerate(items[:4]):
        y = 14 + i * 12
        text(f"{item['time']}", 0, y)
        text(f"{item['temp']:>3}C", 38, y)
        desc = str(item["desc"])[:9]
        text(desc, 70, y)

    show()

def page_aqi():
    city  = CITIES[state["city"]]
    label = CITY_LABELS[state["city"]]
    d     = state["data"].get(f"aqi/{city}", default_aqi())

    aqi_val = d.get("aqi", "--")
    cat     = str(d.get("category", ""))

    cls()

    oled.fill_rect(0, 0, WIDTH, 12, 1)
    text(f"AQI      {label[:8]}", 2, 2, 0)

    # AQI index + category
    center_text(f"AQI: {aqi_val}", 16)
    center_text(cat, 28)

    # Bar: AQI 1-5 scale
    hline(40)
    text("Good", 0, 44)
    text("Bad", 104, 44)
    if isinstance(aqi_val, int):
        draw_bar(0, 54, WIDTH, 8, (aqi_val - 1) / 4)

    show()

def page_indoor():
    d = state["data"].get("sensors/indoor", default_indoor())

    cls()

    oled.fill_rect(0, 0, WIDTH, 12, 1)
    text("INDOOR SENSORS", 2, 2, 0)

    text(f"Temp:     {d['temp']} C", 2, 16)
    text(f"Humidity: {d['humidity']}%", 2, 28)
    text(f"Pressure: {d['pressure']}hPa", 2, 40)

    hline(52)
    src = str(d.get("source", ""))[:16]
    text(src, 2, 55)

    show()

PAGE_RENDERERS = [page_weather, page_forecast, page_aqi, page_indoor]

PAGE_NAMES = ["Weather", "Forecast", "AQI", "Indoor"]

def render_status_bar():
    """Draw a tiny page/city indicator — called between pages (optional HUD)."""
    page_label = PAGE_NAMES[state["page"]]
    city_label = CITY_LABELS[state["city"]]
    cls()
    center_text(f"[ {page_label} ]", 20)
    center_text(city_label, 36)
    show()
    time.sleep_ms(400)

def redraw():
    PAGE_RENDERERS[state["page"]]()
    state["dirty"] = False

# ─────────────────────────────────────────────
# BUTTON HANDLING
# ─────────────────────────────────────────────

btn_a = Pin(15, Pin.IN, Pin.PULL_UP)  # cycle pages
btn_b = Pin(17, Pin.IN, Pin.PULL_UP)  # cycle cities

DEBOUNCE_MS = 250

def check_buttons():
    now = time.ticks_ms()
    if time.ticks_diff(now, state["last_press"]) < DEBOUNCE_MS:
        return

    if btn_a.value() == 0:  # pressed (active low)
        state["page"]  = (state["page"] + 1) % len(PAGES)
        state["last_press"] = now
        state["dirty"] = True

    elif btn_b.value() == 0:
        state["city"]  = (state["city"] + 1) % len(CITIES)
        state["last_press"] = now
        state["dirty"] = True

# ─────────────────────────────────────────────
# WIFI
# ─────────────────────────────────────────────

def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if wlan.isconnected():
        return True

    connecting_screen("WiFi...")
    wlan.connect(WIFI_SSID, WIFI_PASS)

    for _ in range(20):
        if wlan.isconnected():
            return True
        time.sleep(0.5)

    return False

# ─────────────────────────────────────────────
# MQTT
# ─────────────────────────────────────────────

mqtt_client = None

def on_message(topic, msg):
    topic_str = topic.decode()
    # Strip base prefix: "homestation/weather/edmonton" → "weather/edmonton"
    if topic_str.startswith(MQTT_BASE + "/"):
        key = topic_str[len(MQTT_BASE) + 1:]
    else:
        key = topic_str

    try:
        data = json.loads(msg)
        state["data"][key] = data
        state["dirty"] = True
    except Exception as e:
        print(f"JSON parse error on {key}: {e}")

def connect_mqtt():
    global mqtt_client
    connecting_screen("MQTT...")
    try:
        mqtt_client = MQTTClient(CLIENT_ID, MQTT_BROKER, MQTT_PORT,
                                 keepalive=60)
        mqtt_client.set_callback(on_message)
        mqtt_client.connect()

        # Subscribe to all relevant topics
        for city in CITIES:
            mqtt_client.subscribe(f"{MQTT_BASE}/weather/{city}")
            mqtt_client.subscribe(f"{MQTT_BASE}/forecast/{city}")
            mqtt_client.subscribe(f"{MQTT_BASE}/aqi/{city}")
        mqtt_client.subscribe(f"{MQTT_BASE}/sensors/indoor")

        print("MQTT connected and subscribed")
        return True
    except Exception as e:
        print(f"MQTT connect failed: {e}")
        return False

def mqtt_check():
    """Non-blocking check for new messages."""
    global mqtt_client
    if mqtt_client is None:
        return
    try:
        mqtt_client.check_msg()
    except Exception as e:
        print(f"MQTT error: {e} — reconnecting")
        mqtt_client = None
        time.sleep(2)
        connect_mqtt()

# ─────────────────────────────────────────────
# MAIN LOOP
# ─────────────────────────────────────────────

def main():
    splash()
    time.sleep(1)

    # Wi-Fi
    if not connect_wifi():
        cls()
        center_text("WiFi FAILED", 24)
        center_text("Check config", 36)
        show()
        return

    # MQTT
    if not connect_mqtt():
        cls()
        center_text("MQTT FAILED", 24)
        center_text("Check broker IP", 36)
        show()
        return

    # Initial draw
    redraw()

    print("HomeStation Pico running")

    while True:
        check_buttons()
        mqtt_check()

        if state["dirty"]:
            redraw()

        gc.collect()
        time.sleep_ms(50)

main()
