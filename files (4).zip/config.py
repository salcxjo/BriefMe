"""
config.py — HomeStation Pico configuration
Copy to Pico root alongside main.py
"""

WIFI_SSID   = "YOUR_WIFI_SSID"
WIFI_PASS   = "YOUR_WIFI_PASSWORD"
MQTT_BROKER = "10.0.0.X"      # Pi 4 local IP address
MQTT_PORT   = 1883
MQTT_BASE   = "homestation"
CLIENT_ID   = "pico-display"

CITIES      = ["edmonton", "tokyo", "vancouver"]
CITY_LABELS = ["Edmonton", "Tokyo", "Vancouver"]
